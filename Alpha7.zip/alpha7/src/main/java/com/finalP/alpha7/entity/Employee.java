package com.finalP.alpha7.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {
	private int eid;
	private String ename;
	private String edes;
	private double esalary;
	private int eage;
	
	@Id
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEdes() {
		return edes;
	}
	public void setEdes(String edes) {
		this.edes = edes;
	}
	public double getEsalary() {
		return esalary;
	}
	public void setEsalary(double esalary) {
		this.esalary = esalary;
	}
	public int getEage() {
		return eage;
	}
	public void setEage(int eage) {
		this.eage = eage;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", edes=" + edes + ", esalary=" + esalary + ", eage="
				+ eage + "]";
	}
	

}
