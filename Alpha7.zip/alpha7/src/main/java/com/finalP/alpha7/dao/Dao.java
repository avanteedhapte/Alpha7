package com.finalP.alpha7.dao;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.finalP.alpha7.entity.Employee;
import com.finalP.alpha7.entity.Student;

@Repository
public class Dao {

	@Autowired
	SessionFactory sf;
	//1
	public List<Student> getStuData() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> stulist = criteria.list();
		session.close();
		return stulist;
	}
    //2
	public Student insertData(Student student) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(student);
		transaction.commit();
		return student;
	}
	//3
	public Student updateData(Student student) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(student);
		transaction.commit();
		return student;
	}
	//4
	public Student getStuDataById(int id) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("id", id));
		Student student = (Student) criteria.list().get(0);
		return student;
	}
	//5
	public Student getStuDataByDep(String dep) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("dep", dep));
		Student student = (Student) criteria.list().get(0);
		return student;
	}
	//6
	public List<Student> getListByDep(String dep) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("dep", dep));
		List<Student> stulist = criteria.list();
		return stulist;
	}
	//7
	public Student getStuDataByName(String name) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.eq("name", name));
		Student student = (Student) criteria.list().get(0);
		return student;
	}
	//8
	public List<Student> getListByletterS(String name) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.like("name", name+"%"));
		List<Student> stulist = criteria.list();
		return stulist;
	}
	//9
	public List<Student> getListBySpecificDep(String dep) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		criteria.add(Restrictions.ne("dep", dep));
		List<Student> stulist = criteria.list();
		return stulist;
	}
	//10
	public List<Employee> getEmpData() {
		Session session = sf.openSession();
		 Criteria criteria = session.createCriteria(Employee.class);
		 List<Employee> emplist = criteria.list();
		 session.close();
		 return emplist;
	}
	//11
	public Employee insertEmpData(Employee emp) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(emp);
		transaction.commit();
		return emp;
	}
	//12
	public Employee updateEmpData(Employee emp) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.update(emp);
		transaction.commit();
		return emp;
	}
	//13
	public Employee getEmpDataById(int eid) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("eid", eid));
		Employee emp = (Employee) criteria.list().get(0);
		return emp;
	}
	//14
	public Employee getEmpByName(String ename) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("ename", ename));
		Employee emp = (Employee) criteria.list().get(0);
		return emp;
	}
	//15
	public Employee getEmpByDes(String edes) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("edes", edes));
		Employee emp = (Employee) criteria.list().get(0);
		return emp;
	}
	//16
	public List<Employee> getEmpListByDes(String edes) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("edes", edes));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//17
	public Employee getEmpByAge(int eage) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("eage", eage));
		Employee emp = (Employee) criteria.list().get(0);
		return emp;
	}
	//18
	public List<Employee> getEmpListBtwnAge(int eage, int eage1) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.between("eage", eage, eage1));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//19
	public List<Employee> getEmpListBtwnId(int eid, int eid1) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.between("eid", eid, eid1));
		List<Employee> emplist = criteria.list();
		return emplist;
	}
	//20
	public Employee getEmpBySalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("esalary", esalary));
		Employee emp = (Employee) criteria.list().get(0);
		return emp;
	}
	//21
	public List<Employee> getEmpListBySalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("esalary", esalary));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//22
	public List<Employee> getEmpListBtwnSalary(double esalary, double esalary1) {
		 Session session = sf.openSession();
		 Criteria criteria = session.createCriteria(Employee.class);
		 criteria.add(Restrictions.between("esalary", esalary, esalary1));
		 List<Employee> emplist = criteria.list();
		 return emplist;
	}
	//23
	public List<Employee> getEmpListgtSalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.gt("esalary", esalary));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//24
	public List<Employee> getEmpListltSalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.lt("esalary", esalary));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//25
	public List<Employee> getEmpListgeSalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.ge("esalary", esalary));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//26
	public List<Employee> getEmpListleSalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.le("esalary", esalary));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//27
	public List<Employee> getEmpListneSalary(double esalary) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.ne("esalary", esalary));
		List<Employee> emplist =  criteria.list();
		return emplist;
	}
	//28
	public List<Employee> getListByNameWithV(String ename) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.like("ename", ename+"%"));
		List<Employee> emplist = criteria.list();
		return emplist;
	}
	//29
	public List<Employee> getListByNameWithSh(String ename) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.like("ename", ename+"%"));
		List<Employee> emplist = criteria.list();
		return emplist;
	}
	//30
	public List<Employee> getListByDesWithLastEr(String edes) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
		criteria.add(Restrictions.like("edes", "%"+edes));
		List<Employee> emplist = criteria.list();
		return emplist;
	}
	}

	


