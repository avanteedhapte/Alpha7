package com.finalP.alpha7.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.finalP.alpha7.entity.Employee;
import com.finalP.alpha7.entity.Student;
import com.finalP.alpha7.service.DataService;

@RestController
public class Controller {
	@Autowired
	DataService dataService;
    // 1 Student Class
	@GetMapping("/getall")
	public List<Student> getStuData() {
	return dataService.getStuData();
	}
    // 2
	@PostMapping("/insertrecord")
	public Student insertData(@RequestBody Student student) {
	return dataService.insertData(student);
	}
    // 3
	@PutMapping("/updaterecord")
	public Student updateData(@RequestBody Student student) {
	return dataService.updateData(student);
	}
    // 4
	@GetMapping("/getdatabyid/{id}")
	public Student getStuDataById(@PathVariable int id) {
	return dataService.getStuDataById(id);
	}
    // 5
	@GetMapping("/getdatabydep/{dep}")
	public Student getStuDataByDep(@PathVariable String dep) {
		return dataService.getStuDataByDep(dep);
	}
	//6
	@GetMapping("/getlistbydep/{dep}")
	public List<Student> getListByDep(@PathVariable String dep) {
		return dataService.getListByDep(dep);
	}
	//7
	@GetMapping("/getdatabyname/{name}")
	public Student getStuDataByName(@PathVariable String name) {
		return dataService.getStuDataByName(name);
	}
	//8
	@GetMapping("/getlistbyletters/{name}")
	public List<Student> getListByletterS(@PathVariable String name) {
		return dataService.getListByletterS(name);
	}
	//9
	@GetMapping("/getlistbyspecificdep/{dep}")
	public List<Student> getListBySpecificDep(@PathVariable String dep) {
		return dataService.getListBySpecificDep(dep);
	}
	//10  Employee Class
	@GetMapping("/getallemp")
	public List<Employee> getEmpData() {
	return dataService.getEmpData();
	}
	//11
	@PostMapping("/insertemprecord")
	public Employee insertEmpData(@RequestBody Employee emp) {
	return dataService.insertEmpData(emp);
	}
	//12
	@PutMapping("/updateemprecord")
	public Employee updateEmpData(@RequestBody Employee emp) {
	return dataService.updateEmpData(emp);
	}
	//13
	@GetMapping("/getdatabyeid/{eid}")
	public Employee getEmpDataById(@PathVariable int eid) {
	return dataService.getEmpDataById(eid);
	}
	//14
	@GetMapping("/getempbyname/{ename}")
	public Employee getEmpByName(@PathVariable String ename) {
		return dataService.getEmpByName(ename);
	}
	//15
	@GetMapping("/getempbydes/{edes}")
	public Employee getEmpByDes(@PathVariable String edes) {
		return dataService.getEmpByDes(edes);
	}
	//16
	@GetMapping("/getemplistbydes/{edes}")
	public List<Employee> getEmpListByDes(@PathVariable String edes) {
		return dataService.getEmpListByDes(edes);
	}
	//17
	@GetMapping("/getempbyage/{eage}")
	public Employee getEmpByAge(@PathVariable int eage) {
		return dataService.getEmpByAge(eage);
	}
	//18
	@GetMapping("/getemplistbtwnAge/{eage}/{eage1}")
	public List<Employee> getEmpListBtwnAge(@PathVariable int eage,@PathVariable int eage1) {
		return dataService.getEmpListBtwnAge(eage,eage1);
	}
	//19
	@GetMapping("/getemplistbtwnId/{eid}/{eid1}")
	public List<Employee> getEmpListBtwnId(@PathVariable int eid,@PathVariable int eid1) {
		return dataService.getEmpListBtwnId(eid,eid1);
	}
	//20
	@GetMapping("/getempbysalary/{esalary}")
	public Employee getEmpBySalary(@PathVariable double esalary) {
		return dataService.getEmpBySalary(esalary);
	}
	//21
	@GetMapping("/getemplistbysalary/{esalary}")
	public List<Employee> getEmpListBySalary(@PathVariable double esalary) {
		return dataService.getEmpListBySalary(esalary);
	}
	//22
	@GetMapping("/getemplistbtwnsalary/{esalary}/{esalary1}")
	public List<Employee> getEmpListBtwnSalary(@PathVariable double esalary,@PathVariable double esalary1) {
		return dataService.getEmpListBtwnSalary(esalary,esalary1);
	}
	//23
	@GetMapping("/getemplistgtsalary/{esalary}")
	public List<Employee> getEmpListgtSalary(@PathVariable double esalary) {
		return dataService.getEmpListgtSalary(esalary);
	}
	//24
	@GetMapping("/getemplistltsalary/{esalary}")
	public List<Employee> getEmpListltSalary(@PathVariable double esalary) {
		return dataService.getEmpListltSalary(esalary);
	}
	//25
	@GetMapping("/getemplistgesalary/{esalary}")
	public List<Employee> getEmpListgeSalary(@PathVariable double esalary) {
		return dataService.getEmpListgeSalary(esalary);
	}
	//26
	@GetMapping("/getemplistlesalary/{esalary}")
	public List<Employee> getEmpListleSalary(@PathVariable double esalary) {
		return dataService.getEmpListleSalary(esalary);
	}
	//27
	@GetMapping("/getemplistnesalary/{esalary}")
	public List<Employee> getEmpListneSalary(@PathVariable double esalary) {
		return dataService.getEmpListneSalary(esalary);
	}
	//28
	@GetMapping("/getlistbynamewithV/{ename}")
	public List<Employee> getListByNameWithV(@PathVariable String ename) {
		return dataService.getListByNameWithV(ename);
	}
	//29
	@GetMapping("/getlistbynamewithSh/{ename}")
	public List<Employee> getListByNameWithSh(@PathVariable String ename) {
		return dataService.getListByNameWithSh(ename);
	}
	//30
	@GetMapping("/getlistbydeswithlastEr/{edes}")
	public List<Employee> getListByDesWithLastEr(@PathVariable String edes) {
		return dataService.getListByDesWithLastEr(edes);
	}
	
	
	

	
	

}
