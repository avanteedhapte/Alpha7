package com.finalP.alpha7.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.finalP.alpha7.dao.Dao;
import com.finalP.alpha7.entity.Employee;
import com.finalP.alpha7.entity.Student;

@Service
public class DataService {
    
	@Autowired
	Dao dao;
	//1
	public List<Student> getStuData() {
	return dao.getStuData();
	}
    //2
	public Student insertData(Student student) {
	return dao.insertData(student);
	}
	//3
	public Student updateData(Student student) {
		return dao.updateData(student);
	}
	//4
	public Student getStuDataById(int id) {
		return dao.getStuDataById(id);
	}
	//5
	public Student getStuDataByDep(String dep) {
		return dao.getStuDataByDep(dep);
	}
	//6
	public List<Student> getListByDep(String dep) {
		return dao.getListByDep(dep);
	}
	//7
	public Student getStuDataByName(String name) {
		return dao.getStuDataByName(name);
	}
	//8
	public List<Student> getListByletterS(String name) {
		return dao.getListByletterS(name);
	}
	//9
	public List<Student> getListBySpecificDep(String dep) {
		return dao.getListBySpecificDep(dep);
	}
	//10
	public List<Employee> getEmpData() {
		return dao.getEmpData();
	}
	//11
	public Employee insertEmpData(Employee emp) {
		return dao.insertEmpData(emp);
	}
	//12
	public Employee updateEmpData(Employee emp) {
		return dao.updateEmpData(emp);
	}
	//13
	public Employee getEmpDataById(int eid) {
		return dao.getEmpDataById(eid);
	}
	//14
	public Employee getEmpByName(String ename) {
		return dao.getEmpByName(ename);
	}
	//15
	public Employee getEmpByDes(String edes) {
		return dao.getEmpByDes(edes);
	}
	//16
	public List<Employee> getEmpListByDes(String edes) {
		return dao.getEmpListByDes(edes);
	}
	//17
	public Employee getEmpByAge(int eage) {
		return dao.getEmpByAge(eage);
	}
	//18
	public List<Employee> getEmpListBtwnAge(int eage, int eage1) {
		return dao.getEmpListBtwnAge(eage,eage1);
	}
	//19
	public List<Employee> getEmpListBtwnId(int eid, int eid1) {
		return dao.getEmpListBtwnId(eid,eid1);
	}
	//20
	public Employee getEmpBySalary(double esalary) {
		return dao.getEmpBySalary(esalary);
	}
	//21
	public List<Employee> getEmpListBySalary(double esalary) {
		return dao.getEmpListBySalary(esalary);
	}
	//22
	public List<Employee> getEmpListBtwnSalary(double esalary, double esalary1) {
		return dao.getEmpListBtwnSalary(esalary,esalary1);
	}
	//23
	public List<Employee> getEmpListgtSalary(double esalary) {
		return dao.getEmpListgtSalary(esalary);
	}
	//24
	public List<Employee> getEmpListltSalary(double esalary) {
		return dao.getEmpListltSalary(esalary);
	}
	//25
	public List<Employee> getEmpListgeSalary(double esalary) {
		return dao.getEmpListgeSalary(esalary);
	}
	//26
	public List<Employee> getEmpListleSalary(double esalary) {
		return dao.getEmpListleSalary(esalary);
	}
	//27
	public List<Employee> getEmpListneSalary(double esalary) {
		return dao.getEmpListneSalary(esalary);
	}
	//28
	public List<Employee> getListByNameWithV(String ename) {
		return dao.getListByNameWithV(ename);
	}
	//29
	public List<Employee> getListByNameWithSh(String ename) {
		return dao.getListByNameWithSh(ename);
	}
	//30
	public List<Employee> getListByDesWithLastEr(String edes) {
		return dao.getListByDesWithLastEr(edes);
	}
	
	
	

}
