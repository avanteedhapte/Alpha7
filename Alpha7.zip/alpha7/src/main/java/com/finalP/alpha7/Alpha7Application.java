package com.finalP.alpha7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Alpha7Application {

	public static void main(String[] args) {
		SpringApplication.run(Alpha7Application.class, args);
	}

}
