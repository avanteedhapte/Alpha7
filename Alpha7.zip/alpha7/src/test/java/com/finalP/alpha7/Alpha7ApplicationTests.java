package com.finalP.alpha7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Alpha7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
